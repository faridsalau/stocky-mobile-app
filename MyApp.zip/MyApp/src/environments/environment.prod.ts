export const environment = {
  production: true,
  firebaseConfig: {
    apiKey: "AIzaSyBEbICmW466AwRAZ_lmH0IlfYj5LVutmrM",
    authDomain: "cs458-mobile-app.firebaseapp.com",
    databaseURL: "https://cs458-mobile-app.firebaseio.com",
    projectId: "cs458-mobile-app",
    storageBucket: "cs458-mobile-app.appspot.com",
    messagingSenderId: "883182105227",
    appId: "1:883182105227:web:791cefba949fbe52371a8e",
  },
};
